import React from 'react';
import './main.css';



export const Main: React.FC = () => {
    return (
        <div className='pic-background'>
            
        </div> 
    )
}